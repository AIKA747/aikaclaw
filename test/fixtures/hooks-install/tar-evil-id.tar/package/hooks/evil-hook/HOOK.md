---
name: evil-hook
description: evil-hook
metadata: {"aikaclaw":{"events":["command:new"]}}
---

# Hook