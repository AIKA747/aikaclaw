---
name: reserved-hook
description: reserved-hook
metadata: {"aikaclaw":{"events":["command:new"]}}
---

# Hook