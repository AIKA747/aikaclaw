---
name: tar-hook
description: tar-hook
metadata: {"aikaclaw":{"events":["command:new"]}}
---

# Hook